# Hotel Reservation Management System (HRMS)

**UML Class Diagram Modelling Assignment**
Kigali Independent University (ULK) | Instructor: Eric Maniraguha

## Group Members

| Name | Student ID |
|---|---|
| Ali Amin | 202512480 |
| Eihassan Ismail | 202513493 |

## Business Idea

A small or medium-sized hotel needs an information system to manage guests, rooms, reservations, payments, additional services, and guest reviews. Many small hotels still use paper or spreadsheets, which causes double bookings, lost payment records, and no clear view of room availability.

## Project Scope

**Covered:** guest registration, room and room-type management, reservations (create, confirm, cancel), check-in and check-out, payments and refunds, additional services, and guest reviews.

**Not covered:** a working application or source code (design only), full hotel accounting, third-party booking sites, inventory and procurement.

## Main Classes

| Class | Responsibility |
|---|---|
| Person (abstract) | Common data for guests and employees |
| Guest | Customer who registers, reserves, cancels, and reviews |
| Employee | Staff who confirm reservations and handle check-in and check-out |
| Hotel | The hotel; owns rooms and employs staff |
| RoomType | Room category (Single, Double, Suite) with price and capacity |
| Room | Physical room with number, floor, and status |
| Reservation | Booking record with dates, status, and total amount |
| Payment | Payment or refund against a reservation |
| Service | Extra service offered (breakfast, laundry, transport) |
| ServiceOrder | Links a reservation to a service with quantity and date |
| Review | Guest rating and comment for a reservation |

## Relationships

| Relationship | Type | Multiplicity |
|---|---|---|
| Guest, Employee to Person | Generalization | n/a |
| Hotel to Room | Composition | 1 to 1..* |
| Hotel to Employee | Aggregation | 1 to 1..* |
| RoomType to Room | Association | 1 to 0..* |
| Guest to Reservation | Association | 1 to 0..* |
| Employee to Reservation | Association | 1 to 0..* |
| Reservation to Room | Association | 0..* to 1..* |
| Reservation to Payment | Composition | 1 to 0..* |
| Reservation to ServiceOrder | Association | 1 to 0..* |
| Service to ServiceOrder | Association | 1 to 0..* |
| Guest to Review | Association | 1 to 0..* |
| Reservation to Review | Association | 1 to 0..1 |

## UML Class Diagram

![UML Class Diagram](diagrams/uml_class_diagram.png)

## Repository Structure

```
uml-class-diagram-assignment/
├── README.md
├── documentation/
│   ├── report_1_project_description.pdf
│   └── report_2_uml_class_diagram.pdf
└── diagrams/
    ├── uml_class_diagram.drawio
    └── uml_class_diagram.png
```
